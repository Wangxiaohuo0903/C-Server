#!/bin/bash

# 启动 Nginx 服务
nginx -g 'daemon off;' &
